# Banco di prova: ISMCTS potenziato (20000 iterazioni) · deduce le carte avversarie (temperatura 1, minimo 25%)

Giocatore `infer:20000:1:1000:0.25`, commit `9da0c27`, 2026-10-29. Seme `20261028`. Prova sequenziale: blocchi di 250 mazzi in duplicato, da 250 a 250 mazzi (500 – 500 partite); ci si ferma prima quando il risultato rispetto alla soglia è certo al 99,5%.

| Famiglia | Avversari | Sopra la soglia | Sotto la soglia | Al limite |
|---|---:|---:|---:|---:|

1000 partite, 0.5 ore di calcolo su questa macchina.

## Super-bari (tetto)

Vedono le carte nascoste: non sono un obiettivo, dicono quanto margine resta.

| Avversario | Partite | Punteggio | IC 95% | Obiettivo |
|---|---:|---:|---|---|
| Baro: vede le carte avversarie, ISMCTS potenziato (20000 iterazioni) | 500 | **27,8%** | 24,0% – 31,6% | misura |
| Super-baro: vede mano avversaria e mazzo, ISMCTS potenziato (20000 iterazioni) | 500 | **4,1%** | 2,5% – 5,7% | misura |

