# Banco di prova: ISMCTS potenziato (20000 iterazioni) · deduce le carte avversarie (temperatura 1, minimo 25%)

Giocatore `infer:20000:1:1000:0.25`, commit `9da0c27`, 2026-10-29. Seme `20261028`. Prova sequenziale: blocchi di 250 mazzi in duplicato, da 500 a 500 mazzi (1000 – 1000 partite); ci si ferma prima quando il risultato rispetto alla soglia è certo al 99,5%.

| Famiglia | Avversari | Sopra la soglia | Sotto la soglia | Al limite |
|---|---:|---:|---:|---:|
| Avversari cattivi | 3 | 3 | 0 | 0 |

3000 partite, 1.1 ore di calcolo su questa macchina.

## Avversari cattivi

Chi non si lascia prevedere: cambia stile a metà partita o sceglie a caso tra le mosse buone. Gli sfruttatori allenati contro il motore arrivano nella fase 8.

| Avversario | Partite | Punteggio | IC 95% | Obiettivo |
|---|---:|---:|---|---|
| Camaleonte: cambia stile ogni 4 prese tra 7 stili | 1000 | **77,9%** | 75,4% – 80,4% | ✅ sopra il 50% |
| Camaleonte: cambia stile ogni 4 prese tra 7 stili | 1000 | **77,4%** | 74,9% – 79,9% | ✅ sopra il 50% |
| Imprevedibile: ISMCTS potenziato (20000 iterazioni) che sceglie a caso tra le mosse buone | 1000 | **54,5%** | 51,8% – 57,3% | ✅ sopra il 50% |

