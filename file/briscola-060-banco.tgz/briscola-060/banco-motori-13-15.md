# Banco di prova: ISMCTS potenziato (20000 iterazioni) · deduce le carte avversarie (temperatura 1, minimo 25%)

Giocatore `infer:20000:1:1000:0.25`, commit `9da0c27`, 2026-10-29. Seme `20261028`. Prova sequenziale: blocchi di 250 mazzi in duplicato, da 500 a 500 mazzi (1000 – 1000 partite); ci si ferma prima quando il risultato rispetto alla soglia è certo al 99,5%.

| Famiglia | Avversari | Sopra la soglia | Sotto la soglia | Al limite |
|---|---:|---:|---:|---:|
| Motori forti | 2 | 1 | 0 | 1 |

2000 partite, 0.6 ore di calcolo su questa macchina.

## Motori forti

Forza pura contro algoritmi diversi, fino a 100.000 iterazioni, e contro le versioni rilasciate.

| Avversario | Partite | Punteggio | IC 95% | Obiettivo |
|---|---:|---:|---|---|
| Motore PIMC (1000 mondi) [v0.2.0] | 1000 | **52,8%** | 50,0% – 55,6% | ≈ al limite |
| Motore PIMC (1000 mondi) [v0.1.1] | 1000 | **60,5%** | 57,6% – 63,3% | ✅ sopra il 50% |

