# Banco di prova: ISMCTS potenziato (20000 iterazioni) · deduce le carte avversarie (temperatura 1, minimo 25%)

Giocatore `infer:20000:1:1000:0.25`, commit `9da0c27`, 2026-10-29. Seme `20261028`. Prova sequenziale: blocchi di 250 mazzi in duplicato, da 500 a 500 mazzi (1000 – 1000 partite); ci si ferma prima quando il risultato rispetto alla soglia è certo al 99,5%.

| Famiglia | Avversari | Sopra la soglia | Sotto la soglia | Al limite |
|---|---:|---:|---:|---:|
| Motori forti | 1 | 1 | 0 | 0 |

1000 partite, 0.8 ore di calcolo su questa macchina.

## Motori forti

Forza pura contro algoritmi diversi, fino a 100.000 iterazioni, e contro le versioni rilasciate.

| Avversario | Partite | Punteggio | IC 95% | Obiettivo |
|---|---:|---:|---|---|
| ISMCTS potenziato (20000 iterazioni) | 1000 | **53,5%** | 50,7% – 56,3% | ✅ sopra il 50% |

