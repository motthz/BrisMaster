# Banco di prova: ISMCTS potenziato (20000 iterazioni) · deduce le carte avversarie (temperatura 1, minimo 25%)

Giocatore `infer:20000:1:1000:0.25`, commit `9da0c27`, 2026-10-29. Seme `20261028`. Prova sequenziale: blocchi di 250 mazzi in duplicato, da 1000 a 1000 mazzi (2000 – 2000 partite); ci si ferma prima quando il risultato rispetto alla soglia è certo al 99,5%.

| Famiglia | Avversari | Sopra la soglia | Sotto la soglia | Al limite |
|---|---:|---:|---:|---:|
| Motori forti | 1 | 1 | 0 | 0 |

2000 partite, 0.6 ore di calcolo su questa macchina.

## Motori forti

Forza pura contro algoritmi diversi, fino a 100.000 iterazioni, e contro le versioni rilasciate.

| Avversario | Partite | Punteggio | IC 95% | Obiettivo |
|---|---:|---:|---|---|
| Motore PIMC (400 mondi) | 2000 | **56,5%** | 54,4% – 58,5% | ✅ sopra il 50% |

