# Banco di prova: ISMCTS potenziato (20000 iterazioni) · deduce le carte avversarie (temperatura 1, minimo 25%)

Giocatore `infer:20000:1:1000:0.25`, commit `9da0c27`, 2026-10-28. Seme `20261028`. Prova sequenziale: blocchi di 250 mazzi in duplicato, da 250 a 4000 mazzi (500 – 8000 partite); ci si ferma prima quando il risultato rispetto alla soglia è certo al 99,5%.

| Famiglia | Avversari | Sopra la soglia | Sotto la soglia | Al limite |
|---|---:|---:|---:|---:|
| Popolazione di personaggi | 20 | 20 | 0 | 0 |

50000 partite, 1.5 ore di calcolo su questa macchina.

## Popolazione di personaggi

Giocatori generati a caso da 12 manopole: si cercano i più difficili e si gioca a fondo contro quelli.

Vaglio: 200 personaggi, 200 partite ciascuno contro ISMCTS potenziato (2000 iterazioni). Punteggio minimo 64,0%, primo quartile 72,2%, mediana 75,5%, massimo 88,8%; sopra il 60%: 200 su 200. I 20 più difficili passano alla prova completa qui sotto.

| Avversario | Partite | Punteggio | IC 95% | Obiettivo |
|---|---:|---:|---|---|
| Personaggio n. 41 | 500 | **73,2%** | 69,6% – 76,8% | ✅ sopra il 60% |
| Personaggio n. 70 | 500 | **75,0%** | 71,6% – 78,4% | ✅ sopra il 60% |
| Personaggio n. 47 | 500 | **78,3%** | 74,8% – 81,8% | ✅ sopra il 60% |
| Personaggio n. 162 | 500 | **72,6%** | 68,8% – 76,4% | ✅ sopra il 60% |
| Personaggio n. 197 | 500 | **74,5%** | 70,9% – 78,1% | ✅ sopra il 60% |
| Personaggio n. 109 | 500 | **76,1%** | 72,5% – 79,7% | ✅ sopra il 60% |
| Personaggio n. 178 | 500 | **77,3%** | 73,9% – 80,7% | ✅ sopra il 60% |
| Personaggio n. 66 | 500 | **76,1%** | 72,4% – 79,8% | ✅ sopra il 60% |
| Personaggio n. 154 | 500 | **79,2%** | 75,9% – 82,5% | ✅ sopra il 60% |
| Personaggio n. 38 | 500 | **76,2%** | 72,9% – 79,5% | ✅ sopra il 60% |
| Personaggio n. 130 | 500 | **79,9%** | 76,5% – 83,3% | ✅ sopra il 60% |
| Personaggio n. 63 | 500 | **73,7%** | 70,1% – 77,3% | ✅ sopra il 60% |
| Personaggio n. 81 | 500 | **74,3%** | 70,7% – 77,9% | ✅ sopra il 60% |
| Personaggio n. 61 | 500 | **80,3%** | 77,0% – 83,6% | ✅ sopra il 60% |
| Personaggio n. 60 | 500 | **74,5%** | 70,8% – 78,2% | ✅ sopra il 60% |
| Personaggio n. 53 | 500 | **73,4%** | 69,7% – 77,1% | ✅ sopra il 60% |
| Personaggio n. 62 | 500 | **77,1%** | 73,4% – 80,8% | ✅ sopra il 60% |
| Personaggio n. 58 | 500 | **74,6%** | 71,0% – 78,2% | ✅ sopra il 60% |
| Personaggio n. 98 | 500 | **75,7%** | 72,1% – 79,3% | ✅ sopra il 60% |
| Personaggio n. 119 | 500 | **77,6%** | 74,2% – 81,0% | ✅ sopra il 60% |

