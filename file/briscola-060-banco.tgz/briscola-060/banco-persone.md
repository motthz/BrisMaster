# Banco di prova: ISMCTS potenziato (20000 iterazioni) · deduce le carte avversarie (temperatura 1, minimo 25%)

Giocatore `infer:20000:1:1000:0.25`, commit `de11b62`, 2026-10-28. Seme `20261028`. Prova sequenziale: blocchi di 250 mazzi in duplicato, da 250 a 4000 mazzi (500 – 8000 partite); ci si ferma prima quando il risultato rispetto alla soglia è certo al 99,5%.

| Famiglia | Avversari | Sopra la soglia | Sotto la soglia | Al limite |
|---|---:|---:|---:|---:|
| Persone vere | 10 | 10 | 0 | 0 |

6500 partite, 1.3 ore di calcolo su questa macchina.

## Persone vere

Giocatori bravi sotto pressione: il tempo che stringe, il tilt quando sono sotto, la distrazione.

| Avversario | Partite | Punteggio | IC 95% | Obiettivo |
|---|---:|---:|---|---|
| Contacarte · il tempo stringe (fino a 40% di errori) | 500 | **79,7%** | 76,2% – 83,2% | ✅ sopra il 60% |
| Stile «circolo» (esperto da circolo: ricorda quasi tutto, sbaglia di rado) · il tempo stringe (fino a 40% di errori) | 500 | **76,7%** | 73,2% – 80,2% | ✅ sopra il 60% |
| Contacarte · va in tilt quando è sotto (40% di errori) | 500 | **76,2%** | 72,5% – 79,9% | ✅ sopra il 60% |
| Stile «circolo» (esperto da circolo: ricorda quasi tutto, sbaglia di rado) · va in tilt quando è sotto (40% di errori) | 500 | **77,4%** | 74,0% – 80,8% | ✅ sopra il 60% |
| Contacarte con 5% di errori | 500 | **77,0%** | 73,4% – 80,6% | ✅ sopra il 60% |
| Stile «memoria-perfetta» (ricorda tutto e gioca il finale perfetto) con 10% di errori | 500 | **74,4%** | 70,9% – 77,9% | ✅ sopra il 60% |
| Stile «nonno» (il nonno: lento e attento, tiene le briscole, sbaglia poco) · il tempo stringe (fino a 30% di errori) | 500 | **80,1%** | 76,8% – 83,4% | ✅ sopra il 60% |
| Stile «spavaldo» (spavaldo: apre forte e prende tutto quello che può) · va in tilt quando è sotto (30% di errori) | 500 | **79,2%** | 75,8% – 82,6% | ✅ sopra il 60% |
| Stile «domenica» (giocatore della domenica: distratto, ricorda poco) · il tempo stringe (fino a 50% di errori) | 500 | **83,2%** | 79,9% – 86,5% | ✅ sopra il 60% |
| Motore PIMC (400 mondi) con 10% di errori | 2000 | **64,3%** | 62,3% – 66,4% | ✅ sopra il 60% |

