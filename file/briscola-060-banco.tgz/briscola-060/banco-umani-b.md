# Banco di prova: ISMCTS potenziato (20000 iterazioni) · deduce le carte avversarie (temperatura 1, minimo 25%)

Giocatore `infer:20000:1:1000:0.25`, commit `de11b62`, 2026-10-28. Seme `20261028`. Prova sequenziale: blocchi di 250 mazzi in duplicato, da 250 a 4000 mazzi (500 – 8000 partite); ci si ferma prima quando il risultato rispetto alla soglia è certo al 99,5%.

| Famiglia | Avversari | Sopra la soglia | Sotto la soglia | Al limite |
|---|---:|---:|---:|---:|
| Stili umani | 13 | 13 | 0 | 0 |

6500 partite, 1.5 ore di calcolo su questa macchina.

## Stili umani

Le abitudini tipiche da tavolo: i 10 stili scritti a mano e i 20 stili con nome.

| Avversario | Partite | Punteggio | IC 95% | Obiettivo |
|---|---:|---:|---|---|
| Stile «memoria-perfetta» (ricorda tutto e gioca il finale perfetto) | 500 | **71,1%** | 67,4% – 74,8% | ✅ sopra il 60% |
| Stile «prende-tutto» (vuole prendere ogni presa, briscole comprese) | 500 | **77,8%** | 74,4% – 81,2% | ✅ sopra il 60% |
| Stile «avaro» (non molla una briscola nemmeno sotto tortura) | 500 | **80,9%** | 77,5% – 84,3% | ✅ sopra il 60% |
| Stile «apre-di-briscola» (apre di briscola per stanare quelle avversarie) | 500 | **76,2%** | 72,9% – 79,5% | ✅ sopra il 60% |
| Stile «domenica» (giocatore della domenica: distratto, ricorda poco) | 500 | **77,4%** | 73,8% – 81,0% | ✅ sopra il 60% |
| Stile «circolo» (esperto da circolo: ricorda quasi tutto, sbaglia di rado) | 500 | **75,4%** | 71,8% – 79,0% | ✅ sopra il 60% |
| Stile «frettoloso» (il tempo stringe: verso la fine sbaglia sempre di più) | 500 | **80,0%** | 76,5% – 83,5% | ✅ sopra il 60% |
| Stile «cacciatore» (caccia i carichi: briscola appena vede punti in tavola) | 500 | **75,8%** | 72,3% – 79,3% | ✅ sopra il 60% |
| Stile «prudente» (prudente: protegge i punti, prende solo quando costa poco) | 500 | **75,0%** | 71,4% – 78,6% | ✅ sopra il 60% |
| Stile «spavaldo» (spavaldo: apre forte e prende tutto quello che può) | 500 | **76,0%** | 72,4% – 79,6% | ✅ sopra il 60% |
| Stile «nonno» (il nonno: lento e attento, tiene le briscole, sbaglia poco) | 500 | **78,7%** | 75,3% – 82,1% | ✅ sopra il 60% |
| Stile «impulsivo» (impulsivo: prende tutto, sbaglia, ha fretta) | 500 | **80,0%** | 76,5% – 83,5% | ✅ sopra il 60% |
| Stile «calcolatore-distratto» (calcolatore distratto: ricorda tutto ma una mossa su otto è a caso) | 500 | **76,5%** | 72,9% – 80,1% | ✅ sopra il 60% |

