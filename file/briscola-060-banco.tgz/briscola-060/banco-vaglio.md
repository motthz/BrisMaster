# Banco di prova: ISMCTS potenziato (20000 iterazioni) · deduce le carte avversarie (temperatura 1, minimo 25%)

Giocatore `infer:20000:1:1000:0.25`, commit `de11b62`, 2026-10-28. Seme `20261028`. Prova sequenziale: blocchi di 250 mazzi in duplicato, da 500 a 4000 mazzi (1000 – 8000 partite); ci si ferma prima quando il risultato rispetto alla soglia è certo al 99,5%.

| Famiglia | Avversari | Sopra la soglia | Sotto la soglia | Al limite |
|---|---:|---:|---:|---:|
| Popolazione di personaggi | 0 | 0 | 0 | 0 |

40000 partite, 0.7 ore di calcolo su questa macchina.

## Popolazione di personaggi

Giocatori generati a caso da 12 manopole: si cercano i più difficili e si gioca a fondo contro quelli.

Vaglio: 200 personaggi, 200 partite ciascuno contro ISMCTS potenziato (2000 iterazioni). Punteggio minimo 64,0%, primo quartile 72,2%, mediana 75,5%, massimo 88,8%; sopra il 60%: 200 su 200. I 0 più difficili passano alla prova completa qui sotto.

| Avversario | Partite | Punteggio | IC 95% | Obiettivo |
|---|---:|---:|---|---|

