## Diagnosi: dove sbaglia ISMCTS potenziato (20000 iterazioni) · deduce le carte avversarie (temperatura 1, minimo 25%)

17000 decisioni col mazzo non vuoto, da 500 partite contro se stesso. Le giudica un ISMCTS potenziato da 20000 iterazioni che vede la mano avversaria. **Mosse diverse**: quante volte l'oracolo avrebbe giocato un'altra carta. **Vittorie perse**: probabilità di vittoria persa per decisione, secondo l'oracolo; sommata su una partita dice quanto costa non sapere le carte.

| Momento | Decisioni | Mosse diverse | Vittorie perse per decisione | Vittorie perse a partita | Quota del totale |
|---|---:|---:|---:|---:|---:|
| Mazzo 30–33 (prime prese) | 3000 | 38,9% | 1,4% | 4,2% | 17,3% |
| Mazzo 24–29 | 3000 | 33,0% | 1,4% | 4,3% | 17,5% |
| Mazzo 18–23 | 3000 | 31,4% | 1,7% | 5,0% | 20,3% |
| Mazzo 12–17 | 3000 | 30,2% | 1,5% | 4,6% | 18,6% |
| Mazzo 6–11 | 3000 | 29,5% | 1,6% | 4,7% | 19,3% |
| Mazzo 1–5 (pre-finale) | 2000 | 26,2% | 0,9% | 1,7% | 7,0% |
| Quando apre | 8500 | 48,1% | 2,5% | 21,3% | 86,9% |
| Quando risponde | 8500 | 15,7% | 0,4% | 3,2% | 13,1% |
