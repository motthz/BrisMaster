## Esame del finale: ISMCTS potenziato (20000 iterazioni) · deduce le carte avversarie (temperatura 1, minimo 25%)

20000 posizioni a mazzo vuoto prese da partite tra personaggi, scelte solo dove la carta giocata cambia l'esito. La mossa giusta è calcolata in modo esatto. Giuste: **20000 su 20000 (100,0%)**.

| Situazione | Posizioni | Giuste |
|---|---:|---:|
| 3 carte in mano, apre | 5184 | 100,0% |
| 3 carte in mano, risponde | 9184 | 100,0% |
| 2 carte in mano, apre | 964 | 100,0% |
| 2 carte in mano, risponde | 4668 | 100,0% |
